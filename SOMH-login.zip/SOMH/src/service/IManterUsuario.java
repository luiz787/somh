/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import domain.Usuario;
import exception.BusinessException;
import exception.PersistenceException;
import java.util.List;

/**
 *
 * @author aluno
 */
public interface IManterUsuario {
    public Long cadastrar(Usuario usuario) throws PersistenceException, BusinessException;
    public boolean alterar(Usuario usuario) throws PersistenceException, BusinessException;
    public boolean excluir(Usuario usuario) throws PersistenceException, BusinessException;
    public List<Usuario> pesquisarTodos() throws PersistenceException;
    public Usuario pesquisarPorId(Long id) throws PersistenceException;
}
