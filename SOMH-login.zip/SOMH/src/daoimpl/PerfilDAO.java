/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package daoimpl;

import dao.IPerfilDAO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import domain.Perfil;
import exception.PersistenceException;
import java.util.ArrayList;
import java.util.List;
import util.db.ConnectionManager;

/**
 *
 * @author aluno
 */
public class PerfilDAO implements IPerfilDAO {

    @Override
    public List<Perfil> listarTodos() throws PersistenceException {
        try {
            Connection connection = ConnectionManager.getInstance().getConnection();

            String sql = "SELECT * FROM categoria ORDER BY descricao";

            PreparedStatement pstmt = connection.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();

            ArrayList<Perfil> listAll = null;
            if (rs.next()) {
                listAll = new ArrayList<>();
                do {
                    Perfil perfil = new Perfil();
                    perfil.setId(rs.getLong("id"));
                    perfil.setDescricao(rs.getString("descricao"));
                    listAll.add(perfil);
                } while (rs.next());
            }
            
            rs.close();
            pstmt.close();
            connection.close();

            return listAll;
        } catch (Exception e) {
            e.printStackTrace();
            throw new PersistenceException(e.getMessage());
        }
    }

    @Override
    public Perfil consultarPorId(Long id) throws PersistenceException {
        try {
            Connection connection = ConnectionManager.getInstance().getConnection();

            String sql = "SELECT * FROM categoria WHERE id = ?";

            PreparedStatement pstmt = connection.prepareStatement(sql);
            pstmt.setLong(1, id);
            ResultSet rs = pstmt.executeQuery();

            Perfil perfil = null;
            if (rs.next()) {
                perfil = new Perfil();
                perfil.setId(rs.getLong("id"));
                perfil.setDescricao(rs.getString("descricao"));
            }
            rs.close();
            pstmt.close();
            connection.close();
            
            return perfil;
        } catch (Exception e) {
            e.printStackTrace();
            throw new PersistenceException(e.getMessage());
        }
    }
    
}
