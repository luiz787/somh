/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package serviceimpl;

import dao.IUsuarioDAO;
import daoimpl.UsuarioDAO;
import domain.Usuario;
import exception.BusinessException;
import exception.PersistenceException;
import java.util.List;
import service.IManterUsuario;

/**
 *
 * @author aluno
 */
public class ManterUsuario implements IManterUsuario {

    public ManterUsuario() {
        usuarioDAO = new UsuarioDAO();
    }
    
    private IUsuarioDAO usuarioDAO;

    @Override
    public Long cadastrar(Usuario usuario) throws PersistenceException, BusinessException {
        String error = null;
        if (usuario == null) {
            error += " Usuário deve existir.";
        } else {
            if (usuario.getNome() == null) {
                error += " Nome de usuário não pode estar vazio.";
            }
            if (usuario.getPerfil() == null) {
                error += " Usuário deve ter um perfil.";
            }
            if (usuario.getSenha() == null) {
                error += " Usuário deve ter uma senha.";
            }
            if (error != null) {
                throw new BusinessException(error);
            }
        }
        return usuarioDAO.inserir(usuario);
    }

    @Override
    public boolean alterar(Usuario usuario) throws PersistenceException, BusinessException {
        String error=null;
        if (usuario == null) {
            error += " Usuário deve existir.";
        } else {
            if (usuario.getNome() == null) {
                error += " Nome de usuário nao pode estar vazio.";
            }
            if (usuario.getPerfil() == null) {
                error += " Usuário deve ter um perfil.";
            }
            if (usuario.getSenha() == null) {
                error += " Usuário deve ter uma senha.";
            }
            if (error != null) {
                throw new BusinessException(error);
            }
        }
        return usuarioDAO.atualizar(usuario);
    }

    @Override
    public boolean excluir(Usuario usuario) throws PersistenceException, BusinessException {
        String error = null;
        if (usuario==null){
            error+=" Usuário deve existir.";
        }
        if (error!=null){
            throw new BusinessException(error);
        }
        return usuarioDAO.delete(usuario);
    }

    @Override
    public List<Usuario> pesquisarTodos() throws PersistenceException {
        return usuarioDAO.listarTodos();
    }

    @Override
    public Usuario pesquisarPorId(Long id) throws PersistenceException {
        return usuarioDAO.consultarPorId(id);
    }
    
}
