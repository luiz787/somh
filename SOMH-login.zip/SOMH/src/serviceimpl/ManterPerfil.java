/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package serviceimpl;

import dao.IPerfilDAO;
import daoimpl.PerfilDAO;
import domain.Perfil;
import exception.PersistenceException;
import java.util.List;
import service.IManterPerfil;

/**
 *
 * @author aluno
 */
public class ManterPerfil implements IManterPerfil {

    public ManterPerfil() {
        perfilDAO = new PerfilDAO();
    }
    IPerfilDAO perfilDAO;
    @Override
    public List<Perfil> pesquisarTodos() throws PersistenceException {
        return perfilDAO.listarTodos();
    }

    @Override
    public Perfil pesquisarPorId(Long id) throws PersistenceException {
        return perfilDAO.consultarPorId(id);
    }
    
}
