/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import domain.Usuario;
import exception.PersistenceException;
import java.util.List;

/**
 *
 * @author aluno
 */
public interface IUsuarioDAO {
    public Long inserir(Usuario usuario) throws PersistenceException;

    public boolean atualizar(Usuario usuario) throws PersistenceException;

    public boolean delete(Usuario usuario) throws PersistenceException;

    public List<Usuario> listarTodos() throws PersistenceException;

    public Usuario consultarPorId(Long id) throws PersistenceException;
}
